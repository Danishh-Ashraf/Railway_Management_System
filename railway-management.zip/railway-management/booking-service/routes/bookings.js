const express = require("express");
const router = express.Router();
const Booking = require("../models/Booking");

// Book a train
router.post("/", async (req, res) => {
  try {
    const { userId, trainId, bookingDate, seatsBooked } = req.body;

    // console.log for debugging (optional)
    console.log("Booking Payload received:", { userId, trainId, bookingDate, seatsBooked });

    if (!userId || !trainId || !bookingDate || !seatsBooked) {
      return res.status(400).json({ message: "Please provide all required fields" });
    }

    const booking = new Booking({ userId, trainId, bookingDate, seatsBooked });
    await booking.save();
    res.status(201).json(booking);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Get all bookings
router.get("/", async (req, res) => {
  try {
    const bookings = await Booking.find();
    res.json(bookings);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch bookings" });
  }
});

// Get bookings by userId
router.get("/user/:userId", async (req, res) => {
  try {
    const bookings = await Booking.find({ userId: req.params.userId });
    res.json(bookings);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch user bookings" });
  }
});

// Cancel a booking
router.delete("/:id", async (req, res) => {
  try {
    await Booking.findByIdAndDelete(req.params.id);
    res.json({ message: "Booking cancelled" });
  } catch (err) {
    res.status(500).json({ message: "Failed to cancel booking" });
  }
});

module.exports = router;