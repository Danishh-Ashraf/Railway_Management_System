const mongoose = require("mongoose");

const bookingSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  trainId: { type: String, required: true },       
  bookingDate: { type: Date, required: true },
  seatsBooked: { type: Number, required: true }
});

module.exports = mongoose.model("Booking", bookingSchema);