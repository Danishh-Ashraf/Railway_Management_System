const express = require("express");
const router = express.Router();
const Train = require("../models/Train");

// Get all trains
router.get("/", async (req, res) => {
  try {
    const trains = await Train.find();
    res.json(trains);
  } catch (error) {
    res.status(500).json({ message: "Error fetching trains", error: error.message });
  }
});

// Add a new train
router.post("/", async (req, res) => {
  try {
    const train = new Train(req.body);
    await train.save();
    res.status(201).json(train);
  } catch (error) {
    res.status(400).json({ message: "Error adding train", error: error.message });
  }
});

// Get train by ID
router.get("/:id", async (req, res) => {
  try {
    const train = await Train.findById(req.params.id);
    if (!train) return res.status(404).json({ message: "Train not found" });
    res.json(train);
  } catch (error) {
    res.status(400).json({ message: "Error fetching train", error: error.message });
  }
});

// Update train by ID
router.put("/:id", async (req, res) => {
  try {
    const updatedTrain = await Train.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updatedTrain) return res.status(404).json({ message: "Train not found" });
    res.json(updatedTrain);
  } catch (error) {
    res.status(400).json({ message: "Error updating train", error: error.message });
  }
});

// Delete train
router.delete("/:id", async (req, res) => {
  try {
    const deletedTrain = await Train.findByIdAndDelete(req.params.id);
    if (!deletedTrain) return res.status(404).json({ message: "Train not found" });
    res.json({ message: "Train deleted" });
  } catch (error) {
    res.status(400).json({ message: "Error deleting train", error: error.message });
  }
});

module.exports = router;
