const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const connectDB = require("./config/db");

dotenv.config();
connectDB();

const app = express();

// CORS options
const corsOptions = {
  origin: "http://localhost:3000", // Your frontend URL
  methods: "GET,POST,PUT,DELETE,OPTIONS",
  credentials: true,
};
app.use(cors(corsOptions));

app.use(express.json());

app.use("/api/trains", require("./routes/trains"));

app.get("/", (req, res) => {
  res.send("Train Service is running.");
});

const PORT = process.env.PORT || 5002;
app.listen(PORT, () => console.log(`🚆 Train Service running on port ${PORT}`));
